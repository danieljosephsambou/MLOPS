import pandas as pd
import joblib
from app.preprocess import build_pipeline

def train_and_save_model():
    df = pd.read_csv("data/house_data.csv")
    
    y = df["price"]
    X = df.drop("price", axis=1)

    numeric = X.select_dtypes(include="number").columns.tolist()
    categorical = X.select_dtypes(include="object").columns.tolist()

    pipeline = build_pipeline(numeric, categorical)
    model = pipeline.fit(X, y)
    
    joblib.dump(model, "model/model.pkl")

if __name__ == "__main__":
    train_and_save_model()
