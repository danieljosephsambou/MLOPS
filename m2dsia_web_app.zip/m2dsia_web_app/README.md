# M2DSIA Web Logger

Projet de démonstration du logging Python configuré avec YAML.

## Installation

```bash
pip install -r requirements.txt
